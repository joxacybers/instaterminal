"""Widgets for InstaTerminal."""

