"""Screens for InstaTerminal."""

