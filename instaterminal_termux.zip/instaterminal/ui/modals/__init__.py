"""Modals for InstaTerminal."""

