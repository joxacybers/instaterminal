"""Views for InstaTerminal."""

